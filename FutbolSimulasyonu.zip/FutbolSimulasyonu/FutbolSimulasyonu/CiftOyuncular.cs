﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FutbolSimulasyonu
{
    class CiftOyuncular
    {
        public List<Oyuncu> oyuncular1;
        public List<Oyuncu> oyuncular2;

        public CiftOyuncular(List<Oyuncu> oyuncular1, List<Oyuncu> oyuncular2)
        {
            this.oyuncular1 = oyuncular1;
            this.oyuncular2 = oyuncular2;
        }
    }
}
