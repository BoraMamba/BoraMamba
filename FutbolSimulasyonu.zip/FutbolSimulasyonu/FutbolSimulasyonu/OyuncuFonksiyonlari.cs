﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FutbolSimulasyonu
{
    class OyuncuFonksiyonlari
    {
        public List<Oyuncu> Oyuncular
        {
            get;
            set;
        }

        public Oyuncu RastgeleOyuncu(string mevki)
        {
            List<Oyuncu> Temp = new List<Oyuncu>();
            mevki = mevki.Trim(',');
            string[] mevkiler = mevki.Split(',');
            foreach (Oyuncu oyuncu in Oyuncular)
            {
                foreach (string item in mevkiler)
                {
                    if (oyuncu.OyuncuMevki == item)
                        Temp.Add(oyuncu);
                }
            }

            Random rand = new Random();
            int sayi = rand.Next(0, Temp.Count);
            return Temp[sayi];
        }

        public OyuncuFonksiyonlari(List<Oyuncu> Oyuncular)
        {
            this.Oyuncular = Oyuncular;
        }
    }
}
