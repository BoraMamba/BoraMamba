﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FutbolSimulasyonu
{
    class DB
    {
        public static OleDbConnection baglanti = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0; Data Source=Data.accdb");

        public static OleDbConnection Open()
        {
            baglanti.Open();
            return baglanti;
        }

        public static void Close()
        {
            baglanti.Close();
        }

        public static List<Takim> TakimlariAl()
        {
            Open();
            OleDbCommand komut = new OleDbCommand("SELECT * FROM takimlar", baglanti);
            OleDbDataReader okuyucu = komut.ExecuteReader();
            List<Takim> takimlar = new List<Takim>();
            while (okuyucu.Read())
            {
                takimlar.Add(new Takim(int.Parse(okuyucu["ID"].ToString()), okuyucu["TakimAdi"].ToString(), long.Parse(okuyucu["Seyirci"].ToString())));
            }
            Close();
            return takimlar;
        }

        public static void TakimEkle(string takimAdi, int seyirci)
        {
            Open();
            OleDbCommand komut = new OleDbCommand("INSERT INTO takimlar (TakimAdi, Seyirci) VALUES (@TakimAdi, @Seyirci)", baglanti);
            komut.Parameters.AddWithValue("@TakimAdi", takimAdi);
            komut.Parameters.AddWithValue("@Seyirci", seyirci);
            komut.ExecuteNonQuery();
            Close();
        }

        public static List<Millet> UlkeleriAl()
        {
            Open();
            OleDbCommand komut = new OleDbCommand("SELECT * FROM ulkeler", baglanti);
            OleDbDataReader oku = komut.ExecuteReader();
            List<Millet> ulkeler = new List<Millet>();
            while (oku.Read())
            {
                ulkeler.Add(new Millet(int.Parse(oku["ID"].ToString()), oku["UlkeAdi"].ToString(), oku["UlkeIrki"].ToString()));
            }
            Close();
            return ulkeler;
        }

        public static void OyuncuEkle(string ad, string soyad, string mevki, Millet millet, Takim takim, decimal kaleciOzellik1, decimal kaleciOzellik2, decimal kaleciOzellik3, decimal kaleciOzellik4, decimal kaleciOzellik5, decimal oyuncuOzellik1, decimal oyuncuOzellik2, decimal oyuncuOzellik3, decimal oyuncuOzellik4, decimal oyuncuOzellik5, decimal oyuncuOzellik6, decimal oyuncuOzellik7, decimal oyuncuOzellik8, decimal oyuncuOzellik9, decimal oyuncuOzellik10, decimal oyuncuOzellik11)
        {
            Open();
            OleDbCommand komut = new OleDbCommand();
            komut.Parameters.AddWithValue("@Ad", ad);
            komut.Parameters.AddWithValue("@Soyad", soyad);
            komut.Parameters.AddWithValue("@Takim", takim.ID);
            komut.Parameters.AddWithValue("@Millet", millet.ID);
            if (mevki == "Kaleci")
            {
                komut.CommandText = "INSERT INTO kaleciler (OyuncuAdi, OyuncuSoyadi, Takim, OyuncununMilleti, " +
                    "SutKurtarma, PenaltiKurtarma, KafaKurtarma, FrikikKurtarma, " +
                    "TekeTekKurtarma) VALUES (@Ad, @Soyad, @Takim, @Millet, @SutKurtarma, " +
                    "@PenaltiKurtarma, @KafaKurtarma, @FrikikKurtarma, @TekeTekKurtarma)";
                komut.Parameters.AddWithValue("@SutKurtarma", Convert.ToByte(kaleciOzellik1));
                komut.Parameters.AddWithValue("@PenaltiKurtarma", Convert.ToByte(kaleciOzellik2));
                komut.Parameters.AddWithValue("@KafaKurtarma", Convert.ToByte(kaleciOzellik3));
                komut.Parameters.AddWithValue("@FrikikKurtarma", Convert.ToByte(kaleciOzellik4));
                komut.Parameters.AddWithValue("@TekeTekKurtarma", Convert.ToByte(kaleciOzellik5));
            }
            else
            {
                komut.CommandText = "INSERT INTO oyuncular (OyuncuAdi, OyuncuSoyadi, Takim, OyuncununMilleti, OyuncuMevki, PasVerme, PasKesme, " +
                    "SutAtma, SutEngelleme, PenaltiAtma, PenaltiyaSebebiyetVermeme, PenaltiYaptirma, FrikikKullanma, " +
                    "KornerKullanma, KafaHakimiyeti, Bitiricilik) VALUES (@Ad, @Soyad, @Takim, @Millet, @OyuncuMevki," +
                    " @PasVerme, @PasKesme, @SutAtma, @SutEngelleme, @PenaltiAtma, @PenaltiyaSebebiyetVermeme, @PenaltiYaptirma, @FrikikKullanma" +
                    ", @KornerKullanma, @KafaHakimiyeti, @Bitiricilik)";
                komut.Parameters.AddWithValue("@OyuncuMevki", mevki);
                komut.Parameters.AddWithValue("@PasVerme", Convert.ToByte(oyuncuOzellik1));
                komut.Parameters.AddWithValue("@PasKesme", Convert.ToByte(oyuncuOzellik2));
                komut.Parameters.AddWithValue("@SutAtma", Convert.ToByte(oyuncuOzellik3));
                komut.Parameters.AddWithValue("@SutEngelleme", Convert.ToByte(oyuncuOzellik4));
                komut.Parameters.AddWithValue("@PenaltiAtma", Convert.ToByte(oyuncuOzellik5));
                komut.Parameters.AddWithValue("@PenaltiyaSebebiyetVermeme", Convert.ToByte(oyuncuOzellik6));
                komut.Parameters.AddWithValue("@PenaltiYaptirma", Convert.ToByte(oyuncuOzellik7));
                komut.Parameters.AddWithValue("@FrikikKullanma", Convert.ToByte(oyuncuOzellik8));
                komut.Parameters.AddWithValue("@KornerKullanma", Convert.ToByte(oyuncuOzellik9));
                komut.Parameters.AddWithValue("@KafaHakimiyeti", Convert.ToByte(oyuncuOzellik10));
                komut.Parameters.AddWithValue("@Bitiricilik", Convert.ToByte(oyuncuOzellik11));
            }
            komut.Connection = baglanti;
            komut.ExecuteNonQuery();
            Close();
        }

        public static CiftOyuncular OyunculariAl(Takim takim1, Takim takim2)
        {
            Open();
            CiftOyuncular cift = new CiftOyuncular(null, null);
            OleDbCommand komut = new OleDbCommand("SELECT * FROM oyuncular INNER JOIN ulkeler ON oyuncular.OyuncununMilleti = ulkeler.ID WHERE oyuncular.Takim=@id", baglanti);
            komut.Parameters.AddWithValue("@id", takim1.ID);
            OleDbDataReader oku = komut.ExecuteReader();
            List<Oyuncu> oyuncular1 = new List<Oyuncu>();
            List<Oyuncu> oyuncular2 = new List<Oyuncu>();
            while (oku.Read())
            {
                oyuncular1.Add(new Oyuncu(Convert.ToInt32(oku["oyuncular.ID"]), oku["OyuncuAdi"].ToString(), oku["OyuncuSoyadi"].ToString(),
                    takim1, new Millet(0, oku["UlkeAdi"].ToString(), oku["UlkeIrki"].ToString()), oku["OyuncuMevki"].ToString(),
                    Convert.ToByte(oku["PasVerme"]), Convert.ToByte(oku["PasKesme"]), Convert.ToByte(oku["SutAtma"]),
                    Convert.ToByte(oku["SutEngelleme"]), Convert.ToByte(oku["PenaltiAtma"]),
                    Convert.ToByte(oku["PenaltiyaSebebiyetVermeme"]), Convert.ToByte(oku["PenaltiYaptirma"]), Convert.ToByte(oku["FrikikKullanma"]),
                    Convert.ToByte(oku["KornerKullanma"]), Convert.ToByte(oku["KafaHakimiyeti"]), Convert.ToByte(oku["Bitiricilik"])));
            }

            komut.Parameters.Clear();
            komut.Parameters.AddWithValue("@id", takim2.ID);
            oku.Close();
            OleDbDataReader oku2 = komut.ExecuteReader();
            while (oku2.Read())
            {
                oyuncular2.Add(new Oyuncu(Convert.ToInt32(oku2["oyuncular.ID"]), oku2["OyuncuAdi"].ToString(), oku2["OyuncuSoyadi"].ToString(),
                    takim2, new Millet(0, oku2["UlkeAdi"].ToString(), oku2["UlkeIrki"].ToString()), oku2["OyuncuMevki"].ToString(),
                    Convert.ToByte(oku2["PasVerme"]), Convert.ToByte(oku2["PasKesme"]), Convert.ToByte(oku2["SutAtma"]),
                    Convert.ToByte(oku2["SutEngelleme"]), Convert.ToByte(oku2["PenaltiAtma"]),
                    Convert.ToByte(oku2["PenaltiyaSebebiyetVermeme"]), Convert.ToByte(oku2["PenaltiYaptirma"]), Convert.ToByte(oku2["FrikikKullanma"]),
                    Convert.ToByte(oku2["KornerKullanma"]), Convert.ToByte(oku2["KafaHakimiyeti"]), Convert.ToByte(oku2["Bitiricilik"])));
            }
            cift.oyuncular1 = oyuncular1;
            cift.oyuncular2 = oyuncular2;
            Close();
            return cift;
        }

        public static CiftKaleciler KalecileriAl(Takim takim1, Takim takim2)
        {
            CiftKaleciler cift = new CiftKaleciler(null, null);
            Open();
            OleDbCommand komut = new OleDbCommand("SELECT * FROM kaleciler INNER JOIN ulkeler ON kaleciler.OyuncununMilleti = ulkeler.ID WHERE kaleciler.Takim=@id", baglanti);
            komut.Parameters.AddWithValue("@id", takim1.ID);
            OleDbDataReader oku = komut.ExecuteReader();
            List<Kaleci> kaleciler1 = new List<Kaleci>();
            List<Kaleci> kaleciler2 = new List<Kaleci>();
            while (oku.Read())
            {
                kaleciler1.Add(new Kaleci(Convert.ToInt32(oku["kaleciler.ID"]), oku["OyuncuAdi"].ToString(),
                    oku["OyuncuSoyadi"].ToString(), takim1, new Millet(0, oku["UlkeAdi"].ToString(),
                    oku["UlkeIrki"].ToString()), Convert.ToByte(oku["SutKurtarma"]),
                    Convert.ToByte(oku["PenaltiKurtarma"]), Convert.ToByte(oku["KafaKurtarma"]),
                    Convert.ToByte(oku["FrikikKurtarma"]), Convert.ToByte(oku["TekeTekKurtarma"])));
            }
            komut.Parameters.Clear();
            komut.Parameters.AddWithValue("@id", takim2.ID);
            oku.Close();
            OleDbDataReader oku2 = komut.ExecuteReader();
            while (oku2.Read())
            {
                kaleciler2.Add(new Kaleci(Convert.ToInt32(oku2["kaleciler.ID"]), oku2["OyuncuAdi"].ToString(),
                    oku2["OyuncuSoyadi"].ToString(), takim2, new Millet(0, oku2["UlkeAdi"].ToString(),
                    oku2["UlkeIrki"].ToString()), Convert.ToByte(oku2["SutKurtarma"]),
                    Convert.ToByte(oku2["PenaltiKurtarma"]), Convert.ToByte(oku2["KafaKurtarma"]),
                    Convert.ToByte(oku2["FrikikKurtarma"]), Convert.ToByte(oku2["TekeTekKurtarma"])));
            }
            Close();
            cift.kaleciler1 = kaleciler1;
            cift.kaleciler2 = kaleciler2;
            return cift;
        }
    }
}
