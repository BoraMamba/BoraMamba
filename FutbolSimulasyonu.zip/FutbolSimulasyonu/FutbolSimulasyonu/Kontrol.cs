﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FutbolSimulasyonu
{
    class Kontrol
    {
        public int OyuncuSayisi
        {
            get;
            set;
        }

        public bool Kaleci
        {
            get;
            set;
        }

        public Kontrol(int oyuncuSayisi, bool kaleci)
        {
            this.OyuncuSayisi = oyuncuSayisi;
            this.Kaleci = kaleci;
        }
    }
}
