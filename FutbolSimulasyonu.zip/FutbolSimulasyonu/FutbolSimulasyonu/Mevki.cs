﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FutbolSimulasyonu
{
    public class Mevki
    {
        public static string DEFANS = "Defans";
        public static string ORTASAHA = "Orta Saha";
        public static string FORVET = "Forvet";
    }
}
