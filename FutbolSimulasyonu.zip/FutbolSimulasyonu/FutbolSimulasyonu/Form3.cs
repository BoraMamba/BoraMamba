﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Drawing.Text;

/* 
   http://kodevreni.com
   Halit IZGIN(Ready)
   Bu uygulamanın geliştirilmesi tamamen serbesttir.
   Paylaşılması ise kaynak belirtmek şartıyla serbesttir.
   
*/

namespace FutbolSimulasyonu
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void BunifuFlatButton1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Trim() != "")
            {
                DB.TakimEkle(textBox1.Text.Trim(), Convert.ToInt32(numericUpDown1.Value));
                
                MessageBox.Show("Takım Başarıyla Eklendi!\nTakıma Oyuncu Eklemek İçin Oyuncu Ekleme Paneline Gidiniz!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
                MessageBox.Show("Lütfen gerekli alanları doldurun", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            PrivateFontCollection pfc = new PrivateFontCollection();
            Champions.Font(pfc);
            label2.Font = new Font(pfc.Families[0], label2.Font.Size);
            label3.Font = new Font(pfc.Families[0], label3.Font.Size);
            textBox1.Font = new Font(pfc.Families[0], textBox1.Font.Size);
            numericUpDown1.Font = new Font(pfc.Families[0], numericUpDown1.Font.Size);
            bunifuFlatButton1.TextFont = new Font(pfc.Families[0], bunifuFlatButton1.TextFont.Size);
        }

        private void BunifuImageButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BunifuImageButton2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text.Trim() != "")
                bunifuFlatButton1.Enabled = false;
            else
                bunifuFlatButton1.Enabled = true;
        }
    }
}
