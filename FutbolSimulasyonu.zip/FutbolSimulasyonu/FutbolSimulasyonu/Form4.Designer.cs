﻿namespace FutbolSimulasyonu
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.panelKaleci = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.kaleciOzellik5 = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.kaleciOzellik4 = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.kaleciOzellik2 = new System.Windows.Forms.NumericUpDown();
            this.kaleciOzellik3 = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.kaleciOzellik1 = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.yerelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.klasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.efsaneviToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panelOyuncu = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.oyuncuOzellik11 = new System.Windows.Forms.NumericUpDown();
            this.oyuncuOzellik8 = new System.Windows.Forms.NumericUpDown();
            this.label19 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.oyuncuOzellik4 = new System.Windows.Forms.NumericUpDown();
            this.oyuncuOzellik9 = new System.Windows.Forms.NumericUpDown();
            this.oyuncuOzellik6 = new System.Windows.Forms.NumericUpDown();
            this.oyuncuOzellik10 = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.oyuncuOzellik7 = new System.Windows.Forms.NumericUpDown();
            this.label18 = new System.Windows.Forms.Label();
            this.oyuncuOzellik2 = new System.Windows.Forms.NumericUpDown();
            this.label15 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.oyuncuOzellik3 = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.oyuncuOzellik5 = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.oyuncuOzellik1 = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.bunifuImageButton2 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuImageButton1 = new Bunifu.Framework.UI.BunifuImageButton();
            this.label22 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.bunifuFlatButton1 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton2 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.bunifuDragControl2 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.bunifuDragControl3 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.panelKaleci.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kaleciOzellik5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kaleciOzellik4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kaleciOzellik2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kaleciOzellik3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kaleciOzellik1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.panelOyuncu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.oyuncuOzellik11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oyuncuOzellik8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oyuncuOzellik4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oyuncuOzellik9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oyuncuOzellik6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oyuncuOzellik10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oyuncuOzellik7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oyuncuOzellik2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oyuncuOzellik3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oyuncuOzellik5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oyuncuOzellik1)).BeginInit();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.textBox1.Location = new System.Drawing.Point(118, 45);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(120, 20);
            this.textBox1.TabIndex = 0;
            this.textBox1.TextChanged += new System.EventHandler(this.TextBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.label1.Location = new System.Drawing.Point(19, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(22, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Adı";
            // 
            // textBox2
            // 
            this.textBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.textBox2.Location = new System.Drawing.Point(118, 71);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(120, 20);
            this.textBox2.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.label2.Location = new System.Drawing.Point(19, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Soyadı";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.label3.Location = new System.Drawing.Point(19, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Mevkii";
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Kaleci",
            "Defans",
            "Orta Saha",
            "Forvet"});
            this.comboBox1.Location = new System.Drawing.Point(118, 97);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(120, 21);
            this.comboBox1.TabIndex = 2;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.ComboBox1_SelectedIndexChanged);
            // 
            // panelKaleci
            // 
            this.panelKaleci.Controls.Add(this.button1);
            this.panelKaleci.Controls.Add(this.kaleciOzellik5);
            this.panelKaleci.Controls.Add(this.label8);
            this.panelKaleci.Controls.Add(this.kaleciOzellik4);
            this.panelKaleci.Controls.Add(this.label7);
            this.panelKaleci.Controls.Add(this.kaleciOzellik2);
            this.panelKaleci.Controls.Add(this.kaleciOzellik3);
            this.panelKaleci.Controls.Add(this.label5);
            this.panelKaleci.Controls.Add(this.label6);
            this.panelKaleci.Controls.Add(this.kaleciOzellik1);
            this.panelKaleci.Controls.Add(this.label4);
            this.panelKaleci.Enabled = false;
            this.panelKaleci.Location = new System.Drawing.Point(244, 124);
            this.panelKaleci.Name = "panelKaleci";
            this.panelKaleci.Size = new System.Drawing.Size(228, 188);
            this.panelKaleci.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(122, 8);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(103, 43);
            this.button1.TabIndex = 21;
            this.button1.Text = "Rastgele";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // kaleciOzellik5
            // 
            this.kaleciOzellik5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.kaleciOzellik5.Location = new System.Drawing.Point(122, 160);
            this.kaleciOzellik5.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.kaleciOzellik5.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.kaleciOzellik5.Name = "kaleciOzellik5";
            this.kaleciOzellik5.Size = new System.Drawing.Size(103, 20);
            this.kaleciOzellik5.TabIndex = 5;
            this.kaleciOzellik5.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.label8.Location = new System.Drawing.Point(5, 162);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(99, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "Teke Tek Kurtarma";
            // 
            // kaleciOzellik4
            // 
            this.kaleciOzellik4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.kaleciOzellik4.Location = new System.Drawing.Point(122, 134);
            this.kaleciOzellik4.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.kaleciOzellik4.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.kaleciOzellik4.Name = "kaleciOzellik4";
            this.kaleciOzellik4.Size = new System.Drawing.Size(103, 20);
            this.kaleciOzellik4.TabIndex = 5;
            this.kaleciOzellik4.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.label7.Location = new System.Drawing.Point(5, 136);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 13);
            this.label7.TabIndex = 4;
            this.label7.Text = "Frikik Kurtarma";
            // 
            // kaleciOzellik2
            // 
            this.kaleciOzellik2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.kaleciOzellik2.Location = new System.Drawing.Point(122, 82);
            this.kaleciOzellik2.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.kaleciOzellik2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.kaleciOzellik2.Name = "kaleciOzellik2";
            this.kaleciOzellik2.Size = new System.Drawing.Size(103, 20);
            this.kaleciOzellik2.TabIndex = 5;
            this.kaleciOzellik2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // kaleciOzellik3
            // 
            this.kaleciOzellik3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.kaleciOzellik3.Location = new System.Drawing.Point(122, 108);
            this.kaleciOzellik3.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.kaleciOzellik3.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.kaleciOzellik3.Name = "kaleciOzellik3";
            this.kaleciOzellik3.Size = new System.Drawing.Size(103, 20);
            this.kaleciOzellik3.TabIndex = 5;
            this.kaleciOzellik3.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.label5.Location = new System.Drawing.Point(5, 84);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(84, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Penaltı Kurtarma";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.label6.Location = new System.Drawing.Point(5, 109);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "Kafa Kurtarma";
            // 
            // kaleciOzellik1
            // 
            this.kaleciOzellik1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.kaleciOzellik1.Location = new System.Drawing.Point(122, 56);
            this.kaleciOzellik1.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.kaleciOzellik1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.kaleciOzellik1.Name = "kaleciOzellik1";
            this.kaleciOzellik1.Size = new System.Drawing.Size(103, 20);
            this.kaleciOzellik1.TabIndex = 5;
            this.kaleciOzellik1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.label4.Location = new System.Drawing.Point(5, 58);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Şut Kurtarma";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.yerelToolStripMenuItem,
            this.klasToolStripMenuItem,
            this.efsaneviToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(118, 70);
            // 
            // yerelToolStripMenuItem
            // 
            this.yerelToolStripMenuItem.Name = "yerelToolStripMenuItem";
            this.yerelToolStripMenuItem.Size = new System.Drawing.Size(117, 22);
            this.yerelToolStripMenuItem.Text = "Yerel";
            this.yerelToolStripMenuItem.Click += new System.EventHandler(this.YerelToolStripMenuItem_Click);
            // 
            // klasToolStripMenuItem
            // 
            this.klasToolStripMenuItem.Name = "klasToolStripMenuItem";
            this.klasToolStripMenuItem.Size = new System.Drawing.Size(117, 22);
            this.klasToolStripMenuItem.Text = "Klas";
            this.klasToolStripMenuItem.Click += new System.EventHandler(this.KlasToolStripMenuItem_Click);
            // 
            // efsaneviToolStripMenuItem
            // 
            this.efsaneviToolStripMenuItem.Name = "efsaneviToolStripMenuItem";
            this.efsaneviToolStripMenuItem.Size = new System.Drawing.Size(117, 22);
            this.efsaneviToolStripMenuItem.Text = "Efsanevi";
            this.efsaneviToolStripMenuItem.Click += new System.EventHandler(this.EfsaneviToolStripMenuItem_Click);
            // 
            // panelOyuncu
            // 
            this.panelOyuncu.Controls.Add(this.button2);
            this.panelOyuncu.Controls.Add(this.oyuncuOzellik11);
            this.panelOyuncu.Controls.Add(this.oyuncuOzellik8);
            this.panelOyuncu.Controls.Add(this.label19);
            this.panelOyuncu.Controls.Add(this.label16);
            this.panelOyuncu.Controls.Add(this.oyuncuOzellik4);
            this.panelOyuncu.Controls.Add(this.oyuncuOzellik9);
            this.panelOyuncu.Controls.Add(this.oyuncuOzellik6);
            this.panelOyuncu.Controls.Add(this.oyuncuOzellik10);
            this.panelOyuncu.Controls.Add(this.label12);
            this.panelOyuncu.Controls.Add(this.oyuncuOzellik7);
            this.panelOyuncu.Controls.Add(this.label18);
            this.panelOyuncu.Controls.Add(this.oyuncuOzellik2);
            this.panelOyuncu.Controls.Add(this.label15);
            this.panelOyuncu.Controls.Add(this.label17);
            this.panelOyuncu.Controls.Add(this.oyuncuOzellik3);
            this.panelOyuncu.Controls.Add(this.label14);
            this.panelOyuncu.Controls.Add(this.label10);
            this.panelOyuncu.Controls.Add(this.oyuncuOzellik5);
            this.panelOyuncu.Controls.Add(this.label11);
            this.panelOyuncu.Controls.Add(this.label13);
            this.panelOyuncu.Controls.Add(this.oyuncuOzellik1);
            this.panelOyuncu.Controls.Add(this.label9);
            this.panelOyuncu.Location = new System.Drawing.Point(14, 124);
            this.panelOyuncu.Name = "panelOyuncu";
            this.panelOyuncu.Size = new System.Drawing.Size(229, 342);
            this.panelOyuncu.TabIndex = 4;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(118, 8);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(103, 43);
            this.button2.TabIndex = 21;
            this.button2.Text = "Rastgele";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // oyuncuOzellik11
            // 
            this.oyuncuOzellik11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.oyuncuOzellik11.Location = new System.Drawing.Point(118, 316);
            this.oyuncuOzellik11.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.oyuncuOzellik11.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.oyuncuOzellik11.Name = "oyuncuOzellik11";
            this.oyuncuOzellik11.Size = new System.Drawing.Size(103, 20);
            this.oyuncuOzellik11.TabIndex = 5;
            this.oyuncuOzellik11.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // oyuncuOzellik8
            // 
            this.oyuncuOzellik8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.oyuncuOzellik8.Location = new System.Drawing.Point(118, 238);
            this.oyuncuOzellik8.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.oyuncuOzellik8.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.oyuncuOzellik8.Name = "oyuncuOzellik8";
            this.oyuncuOzellik8.Size = new System.Drawing.Size(103, 20);
            this.oyuncuOzellik8.TabIndex = 5;
            this.oyuncuOzellik8.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.label19.Location = new System.Drawing.Point(5, 318);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(44, 13);
            this.label19.TabIndex = 5;
            this.label19.Text = "Bitiricilik";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.label16.Location = new System.Drawing.Point(5, 240);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(78, 13);
            this.label16.TabIndex = 5;
            this.label16.Text = "Frikik Kullanma";
            // 
            // oyuncuOzellik4
            // 
            this.oyuncuOzellik4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.oyuncuOzellik4.Location = new System.Drawing.Point(118, 134);
            this.oyuncuOzellik4.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.oyuncuOzellik4.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.oyuncuOzellik4.Name = "oyuncuOzellik4";
            this.oyuncuOzellik4.Size = new System.Drawing.Size(103, 20);
            this.oyuncuOzellik4.TabIndex = 5;
            this.oyuncuOzellik4.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // oyuncuOzellik9
            // 
            this.oyuncuOzellik9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.oyuncuOzellik9.Location = new System.Drawing.Point(118, 264);
            this.oyuncuOzellik9.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.oyuncuOzellik9.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.oyuncuOzellik9.Name = "oyuncuOzellik9";
            this.oyuncuOzellik9.Size = new System.Drawing.Size(103, 20);
            this.oyuncuOzellik9.TabIndex = 5;
            this.oyuncuOzellik9.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // oyuncuOzellik6
            // 
            this.oyuncuOzellik6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.oyuncuOzellik6.Location = new System.Drawing.Point(118, 186);
            this.oyuncuOzellik6.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.oyuncuOzellik6.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.oyuncuOzellik6.Name = "oyuncuOzellik6";
            this.oyuncuOzellik6.Size = new System.Drawing.Size(103, 20);
            this.oyuncuOzellik6.TabIndex = 5;
            this.oyuncuOzellik6.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // oyuncuOzellik10
            // 
            this.oyuncuOzellik10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.oyuncuOzellik10.Location = new System.Drawing.Point(118, 290);
            this.oyuncuOzellik10.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.oyuncuOzellik10.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.oyuncuOzellik10.Name = "oyuncuOzellik10";
            this.oyuncuOzellik10.Size = new System.Drawing.Size(103, 20);
            this.oyuncuOzellik10.TabIndex = 5;
            this.oyuncuOzellik10.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.label12.Location = new System.Drawing.Point(5, 136);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(75, 13);
            this.label12.TabIndex = 5;
            this.label12.Text = "Şut Engelleme";
            // 
            // oyuncuOzellik7
            // 
            this.oyuncuOzellik7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.oyuncuOzellik7.Location = new System.Drawing.Point(118, 212);
            this.oyuncuOzellik7.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.oyuncuOzellik7.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.oyuncuOzellik7.Name = "oyuncuOzellik7";
            this.oyuncuOzellik7.Size = new System.Drawing.Size(103, 20);
            this.oyuncuOzellik7.TabIndex = 5;
            this.oyuncuOzellik7.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.label18.Location = new System.Drawing.Point(5, 266);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(84, 13);
            this.label18.TabIndex = 5;
            this.label18.Text = "Korner Kullanma";
            // 
            // oyuncuOzellik2
            // 
            this.oyuncuOzellik2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.oyuncuOzellik2.Location = new System.Drawing.Point(118, 82);
            this.oyuncuOzellik2.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.oyuncuOzellik2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.oyuncuOzellik2.Name = "oyuncuOzellik2";
            this.oyuncuOzellik2.Size = new System.Drawing.Size(103, 20);
            this.oyuncuOzellik2.TabIndex = 5;
            this.oyuncuOzellik2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.label15.Location = new System.Drawing.Point(5, 188);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(100, 13);
            this.label15.TabIndex = 5;
            this.label15.Text = "Penaltıya Sebebiyet";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.label17.Location = new System.Drawing.Point(5, 292);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(80, 13);
            this.label17.TabIndex = 5;
            this.label17.Text = "Kafa Hakimiyeti";
            // 
            // oyuncuOzellik3
            // 
            this.oyuncuOzellik3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.oyuncuOzellik3.Location = new System.Drawing.Point(118, 108);
            this.oyuncuOzellik3.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.oyuncuOzellik3.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.oyuncuOzellik3.Name = "oyuncuOzellik3";
            this.oyuncuOzellik3.Size = new System.Drawing.Size(103, 20);
            this.oyuncuOzellik3.TabIndex = 5;
            this.oyuncuOzellik3.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.label14.Location = new System.Drawing.Point(5, 214);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(83, 13);
            this.label14.TabIndex = 5;
            this.label14.Text = "Penaltı Yaptırma";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.label10.Location = new System.Drawing.Point(5, 84);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(60, 13);
            this.label10.TabIndex = 5;
            this.label10.Text = "Pas Kesme";
            // 
            // oyuncuOzellik5
            // 
            this.oyuncuOzellik5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.oyuncuOzellik5.Location = new System.Drawing.Point(118, 160);
            this.oyuncuOzellik5.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.oyuncuOzellik5.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.oyuncuOzellik5.Name = "oyuncuOzellik5";
            this.oyuncuOzellik5.Size = new System.Drawing.Size(103, 20);
            this.oyuncuOzellik5.TabIndex = 5;
            this.oyuncuOzellik5.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.label11.Location = new System.Drawing.Point(5, 110);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(50, 13);
            this.label11.TabIndex = 5;
            this.label11.Text = "Şut Atma";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.label13.Location = new System.Drawing.Point(5, 162);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(66, 13);
            this.label13.TabIndex = 5;
            this.label13.Text = "Penaltı Atma";
            // 
            // oyuncuOzellik1
            // 
            this.oyuncuOzellik1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.oyuncuOzellik1.Location = new System.Drawing.Point(118, 56);
            this.oyuncuOzellik1.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.oyuncuOzellik1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.oyuncuOzellik1.Name = "oyuncuOzellik1";
            this.oyuncuOzellik1.Size = new System.Drawing.Size(103, 20);
            this.oyuncuOzellik1.TabIndex = 5;
            this.oyuncuOzellik1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.label9.Location = new System.Drawing.Point(5, 58);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(58, 13);
            this.label9.TabIndex = 5;
            this.label9.Text = "Pas Verme";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.label20.Location = new System.Drawing.Point(249, 47);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(33, 13);
            this.label20.TabIndex = 5;
            this.label20.Text = "Milleti";
            // 
            // comboBox2
            // 
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(349, 44);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 6;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.ComboBox2_SelectedIndexChanged);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.label21.Location = new System.Drawing.Point(249, 74);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(36, 13);
            this.label21.TabIndex = 5;
            this.label21.Text = "Takım";
            // 
            // comboBox3
            // 
            this.comboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(349, 71);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(121, 21);
            this.comboBox3.TabIndex = 6;
            this.comboBox3.SelectedIndexChanged += new System.EventHandler(this.ComboBox3_SelectedIndexChanged);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.panel8.Controls.Add(this.panel9);
            this.panel8.Controls.Add(this.label22);
            this.panel8.Controls.Add(this.pictureBox2);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel8.Location = new System.Drawing.Point(0, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(553, 38);
            this.panel8.TabIndex = 18;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.bunifuImageButton2);
            this.panel9.Controls.Add(this.bunifuImageButton1);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel9.Location = new System.Drawing.Point(492, 0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(61, 38);
            this.panel9.TabIndex = 2;
            // 
            // bunifuImageButton2
            // 
            this.bunifuImageButton2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuImageButton2.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton2.Image")));
            this.bunifuImageButton2.ImageActive = null;
            this.bunifuImageButton2.Location = new System.Drawing.Point(3, 7);
            this.bunifuImageButton2.Name = "bunifuImageButton2";
            this.bunifuImageButton2.Size = new System.Drawing.Size(24, 24);
            this.bunifuImageButton2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton2.TabIndex = 3;
            this.bunifuImageButton2.TabStop = false;
            this.bunifuImageButton2.Zoom = 10;
            this.bunifuImageButton2.Click += new System.EventHandler(this.BunifuImageButton2_Click);
            // 
            // bunifuImageButton1
            // 
            this.bunifuImageButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.Image")));
            this.bunifuImageButton1.ImageActive = null;
            this.bunifuImageButton1.Location = new System.Drawing.Point(33, 7);
            this.bunifuImageButton1.Name = "bunifuImageButton1";
            this.bunifuImageButton1.Size = new System.Drawing.Size(24, 24);
            this.bunifuImageButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton1.TabIndex = 4;
            this.bunifuImageButton1.TabStop = false;
            this.bunifuImageButton1.Zoom = 10;
            this.bunifuImageButton1.Click += new System.EventHandler(this.BunifuImageButton1_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(45, 6);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(398, 26);
            this.label22.TabIndex = 1;
            this.label22.Text = "Futbol Simülasyon V2.00 - Oyuncu Ekle";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::FutbolSimulasyonu.Properties.Resources.fs_logo_beyaz;
            this.pictureBox2.Location = new System.Drawing.Point(5, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(30, 30);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // bunifuFlatButton1
            // 
            this.bunifuFlatButton1.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton1.BorderRadius = 0;
            this.bunifuFlatButton1.ButtonText = "Yenile";
            this.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton1.Iconimage")));
            this.bunifuFlatButton1.Iconimage_right = null;
            this.bunifuFlatButton1.Iconimage_right_Selected = null;
            this.bunifuFlatButton1.Iconimage_Selected = null;
            this.bunifuFlatButton1.IconMarginLeft = 0;
            this.bunifuFlatButton1.IconMarginRight = 0;
            this.bunifuFlatButton1.IconRightVisible = true;
            this.bunifuFlatButton1.IconRightZoom = 0D;
            this.bunifuFlatButton1.IconVisible = false;
            this.bunifuFlatButton1.IconZoom = 90D;
            this.bunifuFlatButton1.IsTab = false;
            this.bunifuFlatButton1.Location = new System.Drawing.Point(477, 43);
            this.bunifuFlatButton1.Margin = new System.Windows.Forms.Padding(2);
            this.bunifuFlatButton1.Name = "bunifuFlatButton1";
            this.bunifuFlatButton1.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(83)))), ((int)(((byte)(139)))));
            this.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton1.selected = false;
            this.bunifuFlatButton1.Size = new System.Drawing.Size(71, 49);
            this.bunifuFlatButton1.TabIndex = 19;
            this.bunifuFlatButton1.Text = "Yenile";
            this.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton1.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton1.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.bunifuFlatButton1.Click += new System.EventHandler(this.BunifuFlatButton1_Click);
            // 
            // bunifuFlatButton2
            // 
            this.bunifuFlatButton2.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.bunifuFlatButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton2.BorderRadius = 0;
            this.bunifuFlatButton2.ButtonText = "Kaydet";
            this.bunifuFlatButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton2.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton2.Enabled = false;
            this.bunifuFlatButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.bunifuFlatButton2.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton2.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton2.Iconimage")));
            this.bunifuFlatButton2.Iconimage_right = null;
            this.bunifuFlatButton2.Iconimage_right_Selected = null;
            this.bunifuFlatButton2.Iconimage_Selected = null;
            this.bunifuFlatButton2.IconMarginLeft = 0;
            this.bunifuFlatButton2.IconMarginRight = 0;
            this.bunifuFlatButton2.IconRightVisible = true;
            this.bunifuFlatButton2.IconRightZoom = 0D;
            this.bunifuFlatButton2.IconVisible = false;
            this.bunifuFlatButton2.IconZoom = 90D;
            this.bunifuFlatButton2.IsTab = false;
            this.bunifuFlatButton2.Location = new System.Drawing.Point(477, 100);
            this.bunifuFlatButton2.Margin = new System.Windows.Forms.Padding(2);
            this.bunifuFlatButton2.Name = "bunifuFlatButton2";
            this.bunifuFlatButton2.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(31)))), ((int)(((byte)(57)))));
            this.bunifuFlatButton2.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(83)))), ((int)(((byte)(139)))));
            this.bunifuFlatButton2.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton2.selected = false;
            this.bunifuFlatButton2.Size = new System.Drawing.Size(71, 49);
            this.bunifuFlatButton2.TabIndex = 20;
            this.bunifuFlatButton2.Text = "Kaydet";
            this.bunifuFlatButton2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton2.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton2.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.bunifuFlatButton2.Click += new System.EventHandler(this.BunifuFlatButton2_Click);
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.pictureBox2;
            this.bunifuDragControl1.Vertical = true;
            // 
            // bunifuDragControl2
            // 
            this.bunifuDragControl2.Fixed = true;
            this.bunifuDragControl2.Horizontal = true;
            this.bunifuDragControl2.TargetControl = this.panel8;
            this.bunifuDragControl2.Vertical = true;
            // 
            // bunifuDragControl3
            // 
            this.bunifuDragControl3.Fixed = true;
            this.bunifuDragControl3.Horizontal = true;
            this.bunifuDragControl3.TargetControl = this.label22;
            this.bunifuDragControl3.Vertical = true;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(168)))), ((int)(((byte)(168)))));
            this.ClientSize = new System.Drawing.Size(553, 478);
            this.Controls.Add(this.bunifuFlatButton2);
            this.Controls.Add(this.bunifuFlatButton1);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.panelOyuncu);
            this.Controls.Add(this.panelKaleci);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form4";
            this.Text = "Futbol Simülasyon V2.00 - Oyuncu Ekle";
            this.Load += new System.EventHandler(this.Form4_Load);
            this.panelKaleci.ResumeLayout(false);
            this.panelKaleci.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kaleciOzellik5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kaleciOzellik4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kaleciOzellik2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kaleciOzellik3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kaleciOzellik1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.panelOyuncu.ResumeLayout(false);
            this.panelOyuncu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.oyuncuOzellik11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oyuncuOzellik8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oyuncuOzellik4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oyuncuOzellik9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oyuncuOzellik6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oyuncuOzellik10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oyuncuOzellik7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oyuncuOzellik2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oyuncuOzellik3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oyuncuOzellik5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oyuncuOzellik1)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Panel panelKaleci;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown kaleciOzellik1;
        private System.Windows.Forms.NumericUpDown kaleciOzellik5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown kaleciOzellik4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown kaleciOzellik2;
        private System.Windows.Forms.NumericUpDown kaleciOzellik3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panelOyuncu;
        private System.Windows.Forms.NumericUpDown oyuncuOzellik1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown oyuncuOzellik11;
        private System.Windows.Forms.NumericUpDown oyuncuOzellik8;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.NumericUpDown oyuncuOzellik4;
        private System.Windows.Forms.NumericUpDown oyuncuOzellik9;
        private System.Windows.Forms.NumericUpDown oyuncuOzellik6;
        private System.Windows.Forms.NumericUpDown oyuncuOzellik10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.NumericUpDown oyuncuOzellik7;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.NumericUpDown oyuncuOzellik2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.NumericUpDown oyuncuOzellik3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown oyuncuOzellik5;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem yerelToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem klasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem efsaneviToolStripMenuItem;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton2;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton1;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.PictureBox pictureBox2;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton1;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl2;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl3;
    }
}