﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FutbolSimulasyonu
{
    class Millet
    {
        public int ID
        {
            get;
            set;
        }
        public string UlkeAdi
        {
            get;
            set;
        }

        public string UlkeIrki
        {
            get;
            set;
        }
        public Millet(int ID, string UlkeAdi, string UlkeIrki)
        {
            this.ID = ID;
            this.UlkeAdi = UlkeAdi;
            this.UlkeIrki = UlkeIrki;
        }
    }
}
