﻿using Bunifu.Framework.UI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

/* 
   http://kodevreni.com
   Halit IZGIN(Ready)
   Bu uygulamanın geliştirilmesi tamamen serbesttir.
   Paylaşılması ise kaynak belirtmek şartıyla serbesttir.
   
*/

namespace FutbolSimulasyonu
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Kaleci")
            {
                panelKaleci.Enabled = true;
                panelOyuncu.Enabled = false;
                panelKaleci.Location = new Point(14, 124);
                panelOyuncu.Location = new Point(244, 124);
            }
            else
            {
                panelKaleci.Enabled = false;
                panelOyuncu.Enabled = true;
                panelKaleci.Location = new Point(244, 124);
                panelOyuncu.Location = new Point(14, 124);
            }
        }

        private void FontAyarla()
        {
            PrivateFontCollection pfc = new PrivateFontCollection();
            Champions.Font(pfc);
            foreach (Control item in this.Controls)
            {
                if (item is BunifuFlatButton)
                    ((BunifuFlatButton)item).TextFont = new Font(pfc.Families[0], ((BunifuFlatButton)item).TextFont.Size);
                else
                    item.Font = new Font(pfc.Families[0], item.Font.Size);
            }
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            comboBox1.Text = "Defans";
            UlkeleriListele();
            TakimlariListele();

            FontAyarla();
        }

        private void UlkeleriListele()
        {
            List<Millet> ulkeler = DB.UlkeleriAl();
            comboBox2.Items.Clear();

            foreach (Millet ulke in ulkeler)
            {
                comboBox2.Items.Add(ulke);
            }
            comboBox2.DisplayMember = "UlkeIrki";
            comboBox2.ValueMember = "ID";
        }

        private void TakimlariListele()
        {
            List<Takim> takimlar = DB.TakimlariAl();
            comboBox3.Items.Clear();
            comboBox3.DisplayMember = "TakimAdi";
            comboBox3.ValueMember = "ID";
            foreach (Takim item in takimlar)
            {
                comboBox3.Items.Add(item);
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            contextMenuStrip1.Show(Cursor.Position.X, Cursor.Position.Y);
        }

        private int RastOzellik(string tur)
        {
            int rast = 0;
            Random ran = new Random();
            int sayi = ran.Next(1, 101);
            switch (tur)
            {
                case "Yerel":
                    if (sayi <= 30)
                        rast = ran.Next(1, 7);
                    else
                        rast = ran.Next(7, 13);

                    break;
                case "Klas":
                    if (sayi <= 5)
                        rast = ran.Next(1, 4);
                    else if (sayi <= 25)
                        rast = ran.Next(4, 9);
                    else
                        rast = ran.Next(9, 17);
                    break;
                case "Efsanevi":
                    if (sayi <= 3)
                        rast = ran.Next(1, 3);
                    else if (sayi <= 26)
                        rast = ran.Next(3, 12);
                    else
                        rast = ran.Next(12, 21);
                    break;
            }
            return rast;
        }

        private void YerelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Random ran = new Random();
            int dongu;
            string val;
            if (comboBox1.Text == "Kaleci")
            {
                dongu = 5;
                val = "kaleciOzellik";
            }
            else
            {
                dongu = 11;
                val = "oyuncuOzellik";
            }

            for (int i = 1; i <= dongu; i++)
            {
                Thread.Sleep(100);
                if (val == "kaleciOzellik")
                    ((NumericUpDown)panelKaleci.Controls[val + i]).Value = RastOzellik("Yerel");
                else
                    ((NumericUpDown)panelOyuncu.Controls[val + i]).Value = RastOzellik("Yerel");
            }
        }

        private void KlasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Random ran = new Random();
            int dongu;
            string val;
            if (comboBox1.Text == "Kaleci")
            {
                dongu = 5;
                val = "kaleciOzellik";
            }
            else
            {
                dongu = 11;
                val = "oyuncuOzellik";
            }
                

            for (int i = 1; i <= dongu; i++)
            {
                Thread.Sleep(100);
                if (val == "kaleciOzellik")
                    ((NumericUpDown)panelKaleci.Controls[val + i]).Value = RastOzellik("Klas");
                else
                    ((NumericUpDown)panelOyuncu.Controls[val + i]).Value = RastOzellik("Klas");
            }
        }

        private void EfsaneviToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int dongu;
            string val;
            if (comboBox1.Text == "Kaleci")
            {
                dongu = 5;
                val = "kaleciOzellik";
            }
            else
            {
                dongu = 11;
                val = "oyuncuOzellik";
            }


            for (int i = 1; i <= dongu; i++)
            {
                Thread.Sleep(100);
                if (val == "kaleciOzellik")
                    ((NumericUpDown)panelKaleci.Controls[val + i]).Value = RastOzellik("Efsanevi");
                else
                    ((NumericUpDown)panelOyuncu.Controls[val + i]).Value = RastOzellik("Efsanevi");
            }
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            
            MessageBox.Show("Oyuncu Başarıyla Eklendi!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BunifuFlatButton1_Click(object sender, EventArgs e)
        {
            UlkeleriListele();
            TakimlariListele();
        }

        private void BunifuFlatButton2_Click(object sender, EventArgs e)
        {
            string ad = textBox1.Text.Trim();
            string soyad = textBox2.Text.Trim();
            string mevki = comboBox1.Text;
            if (ad != "" && mevki != "" && comboBox2.Text != "" && comboBox3.Text != "")
            {
                Millet millet = (Millet)comboBox2.SelectedItem;
                Takim takim = (Takim)comboBox3.SelectedItem;
                DB.OyuncuEkle(ad, soyad, mevki, millet, takim, kaleciOzellik1.Value, kaleciOzellik2.Value, kaleciOzellik3.Value, kaleciOzellik4.Value, kaleciOzellik5.Value, oyuncuOzellik1.Value, oyuncuOzellik2.Value, oyuncuOzellik3.Value, oyuncuOzellik4.Value, oyuncuOzellik5.Value, oyuncuOzellik6.Value, oyuncuOzellik7.Value, oyuncuOzellik8.Value, oyuncuOzellik9.Value, oyuncuOzellik10.Value, oyuncuOzellik11.Value);
                MessageBox.Show("Oyuncu Başarıyla Eklendi!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
                MessageBox.Show("Lütfen gerekli alanları doldurunuz.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            contextMenuStrip1.Show(Cursor.Position.X, Cursor.Position.Y);
        }

        private void BunifuImageButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BunifuImageButton2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void doValidation()
        {
            if (textBox1.Text.Trim() != "" && comboBox2.Text != "" && comboBox3.Text != "")
                bunifuFlatButton2.Enabled = true;
            else
                bunifuFlatButton2.Enabled = false;
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {
            doValidation();
        }

        private void ComboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            doValidation();
        }

        private void ComboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            doValidation();
        }
    }
}
