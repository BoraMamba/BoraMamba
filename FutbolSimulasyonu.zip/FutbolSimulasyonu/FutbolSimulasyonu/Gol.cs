﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FutbolSimulasyonu
{
    class Gol
    {
        public Oyuncu GolAtanOyuncu
        {
            get;
            set;
        }
        public Takim GolAtanTakim
        {
            get;
            set;
        }

        public int GolDakika
        {
            get;
            set;
        }

        public Gol(Oyuncu golAtan, Takim golAtanaTakim, int dakika)
        {
            this.GolAtanOyuncu = golAtan;
            this.GolAtanTakim = golAtanaTakim;
            this.GolDakika = dakika;
        }
    }
}
