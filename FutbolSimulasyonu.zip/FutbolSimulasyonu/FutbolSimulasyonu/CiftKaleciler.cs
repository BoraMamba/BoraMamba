﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FutbolSimulasyonu
{
    class CiftKaleciler
    {
        public List<Kaleci> kaleciler1;
        public List<Kaleci> kaleciler2;

        public CiftKaleciler(List<Kaleci> kaleciler1, List<Kaleci> kaleciler2)
        {
            this.kaleciler1 = kaleciler1;
            this.kaleciler2 = kaleciler2;
        }
    }
}
