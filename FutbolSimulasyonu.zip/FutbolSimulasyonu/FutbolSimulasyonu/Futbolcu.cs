﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FutbolSimulasyonu
{
    class Futbolcu
    {
        public int ID
        {
            get;
            set;
        }
        public string Adi
        {
            get;
            set;
        }
        public string Soyadi
        {
            get;
            set;
        }

        public string TamAd
        {
            get
            {
                return this.Adi + " " + this.Soyadi;
            }
        }
        public Takim Takim
        {
            get;
            set;
        }
        public Millet Millet
        {
            get;
            set;
        }
    }
}
