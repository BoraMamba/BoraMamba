﻿using Bunifu.Framework.UI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/* 
   http://kodevreni.com
   Halit IZGIN(Ready)
   Bu uygulamanın geliştirilmesi tamamen serbesttir.
   Paylaşılması ise kaynak belirtmek şartıyla serbesttir.
   
*/

namespace FutbolSimulasyonu
{
    public partial class Form5 : Form
    {
        Takim takim1, takim2;

        private void OyunculariEkle()
        {
            CiftOyuncular cift = DB.OyunculariAl(takim1, takim2);
            takim1.Oyuncular = cift.oyuncular1;
            takim2.Oyuncular = cift.oyuncular2;
        }

        private void KalecileriEkle()
        {
            CiftKaleciler cift = DB.KalecileriAl(takim1, takim2);
            takim1.Kaleci = cift.kaleciler1;
            takim2.Kaleci = cift.kaleciler2;
        }

        private void KalecileriDoldur()
        {
            label1.Text = takim1.TakimAdi;
            label2.Text = takim2.TakimAdi;

            foreach (Kaleci kaleci in takim1.Kaleci)
            {
                int ort = 0;
                int count = listView3.Items.Count;
                listView3.Items.Add(kaleci.ID.ToString());
                listView3.Items[count].SubItems.Add(kaleci.TamAd);
                listView3.Items[count].SubItems.Add(kaleci.Millet.UlkeIrki);
                ort = (kaleci.KafaKurtarma + kaleci.PenaltiKurtarma + kaleci.SutKurtarma + kaleci.TekeTekKurtarma + kaleci.FrikikKurtarma) / 5;
                listView3.Items[count].SubItems.Add(ort.ToString());
            }

            foreach (Kaleci kaleci in takim2.Kaleci)
            {
                int ort = 0;
                int count = listView4.Items.Count;
                listView4.Items.Add(kaleci.ID.ToString());
                listView4.Items[count].SubItems.Add(kaleci.TamAd);
                listView4.Items[count].SubItems.Add(kaleci.Millet.UlkeIrki);
                ort = (kaleci.KafaKurtarma + kaleci.PenaltiKurtarma + kaleci.SutKurtarma + kaleci.TekeTekKurtarma + kaleci.FrikikKurtarma) / 5;
                listView4.Items[count].SubItems.Add(ort.ToString());
            }
        }

        private void OyunculariDoldur()
        {
            int t1Ort = 0, t2Ort = 0;
            foreach (Oyuncu oyuncu in takim1.Oyuncular)
            {
                int count = listView1.Items.Count;
                listView1.Items.Add(oyuncu.ID.ToString());
                listView1.Items[count].SubItems.Add(oyuncu.TamAd);
                listView1.Items[count].SubItems.Add(oyuncu.OyuncuMevki);
                listView1.Items[count].SubItems.Add(oyuncu.Millet.UlkeIrki);
                int ort = (oyuncu.KafaHakimiyeti + oyuncu.KornerKullanma + oyuncu.PasKesme + oyuncu.PasVerme + oyuncu.PenaltiAtma + oyuncu.PenaltiYaptirma + oyuncu.PenaltiyaSebebiyetVermeme + oyuncu.SutAtma + oyuncu.SutEngelleme + oyuncu.FrikikKullanma + oyuncu.Bitiricilik) / 11;
                t1Ort += ort;
                listView1.Items[count].SubItems.Add(ort.ToString());
            }

            foreach (Oyuncu oyuncu in takim2.Oyuncular)
            {
                int count = listView2.Items.Count;
                listView2.Items.Add(oyuncu.ID.ToString());
                listView2.Items[count].SubItems.Add(oyuncu.TamAd);
                listView2.Items[count].SubItems.Add(oyuncu.OyuncuMevki);
                listView2.Items[count].SubItems.Add(oyuncu.Millet.UlkeIrki);
                int ort = (oyuncu.KafaHakimiyeti + oyuncu.KornerKullanma + oyuncu.PasKesme + oyuncu.PasVerme + oyuncu.PenaltiAtma + oyuncu.PenaltiYaptirma + oyuncu.PenaltiyaSebebiyetVermeme + oyuncu.SutAtma + oyuncu.SutEngelleme + oyuncu.FrikikKullanma + oyuncu.Bitiricilik) / 11;
                t2Ort += ort;
                listView2.Items[count].SubItems.Add(ort.ToString());
            }

            label1.Text += "(" + (t1Ort / takim1.Oyuncular.Count) + ")";
            label2.Text += "(" + (t2Ort / takim2.Oyuncular.Count) + ")";
        }

        ListView secilen;

        private void FontlariAyarla()
        {
            PrivateFontCollection pfc = new PrivateFontCollection();
            Champions.Font(pfc);

            foreach (Control item in this.Controls)
            {
                if (item is BunifuFlatButton)
                    ((BunifuFlatButton)item).TextFont = new Font(pfc.Families[0], ((BunifuFlatButton)item).TextFont.Size);
                else
                    item.Font = new Font(pfc.Families[0], item.Font.Size);
            }
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            OyunculariEkle();
            KalecileriEkle();

            KalecileriDoldur();
            OyunculariDoldur();


        }
        bool t1Hazir = false, t2Hazir = false;
        private void ListView1_ItemChecked(object sender, ItemCheckedEventArgs e)
        {
            if (listView1.CheckedItems.Count == 10)
                t1Hazir = true;
            else
                t1Hazir = false;

            doValidation();

            if (listView1.CheckedItems.Count == 10)
                label3.ForeColor = Color.Green;
            else
                label3.ForeColor = Color.DarkRed;

            label3.Text = listView1.CheckedItems.Count + " adet oyuncu seçtiniz.";
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            
        }

        private void Form5_FormClosing(object sender, FormClosingEventArgs e)
        {
            Form1 form1 = (Form1)Application.OpenForms["Form1"];
            form1.Show();
        }

        private void ListView1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                secilen = listView1;
            }
        }

        private void ListView2_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                secilen = listView2;
            }
        }

        private void TümünüSeçToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem item in secilen.Items)
            {
                item.Checked = true;
            }
        }

        private void TümününSeçiminiKaldırToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem item in secilen.Items)
            {
                item.Checked = false;
            }
        }

        private void SeçimiTersineÇevirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem item in secilen.Items)
            {
                item.Checked = !item.Checked;
            }
        }

        private void BunifuFlatButton1_Click(object sender, EventArgs e)
        {
            List<int> silinecekler1 = new List<int>();
            foreach (ListViewItem item in listView1.Items)
            {
                if (!item.Checked)
                    silinecekler1.Add(Convert.ToInt32(item.Text));
            }

            List<int> silinecekler2 = new List<int>();
            foreach (ListViewItem item in listView2.Items)
            {
                if (!item.Checked)
                    silinecekler2.Add(Convert.ToInt32(item.Text));
            }

            foreach (int item in silinecekler1)
            {
                int index = takim1.Oyuncular.FindIndex(i => i.ID == item);
                takim1.Oyuncular.RemoveAt(index);
            }

            foreach (int item in silinecekler2)
            {
                int index = takim2.Oyuncular.FindIndex(i => i.ID == item);
                takim2.Oyuncular.RemoveAt(index);
            }

            for (int i = 0; i < takim1.Kaleci.Count; i++)
            {
                Kaleci item = takim1.Kaleci.Find(kaleci => kaleci.ID == Convert.ToInt32(listView3.CheckedItems[0].Text));
                if (takim1.Kaleci[i].ID != item.ID)
                    takim1.Kaleci.RemoveAt(i);
            }

            for (int i = 0; i < takim2.Kaleci.Count; i++)
            {
                Kaleci item = takim2.Kaleci.Find(kaleci2 => kaleci2.ID == Convert.ToInt32(listView4.CheckedItems[0].Text));
                if (takim2.Kaleci[i].ID != item.ID)
                    takim2.Kaleci.RemoveAt(i);
            }

            Form2 form2 = new Form2(takim1, takim2);
            form2.Show();
            this.Hide();
        }

        private void BunifuImageButton1_Click(object sender, EventArgs e)
        {
            Form1 form1 = (Form1)Application.OpenForms["Form1"];
            form1.Show();
            this.Hide();
        }

        private void BunifuImageButton2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void doValidation()
        {
            if (listView3.CheckedItems.Count == 1 && listView4.CheckedItems.Count == 1 && t1Hazir && t2Hazir)
                bunifuFlatButton1.Enabled = true;
            else
                bunifuFlatButton1.Enabled = false;
        }

        private void ListView3_ItemChecked(object sender, ItemCheckedEventArgs e)
        {
            if (e.Item.Checked == true)
            {
                foreach (ListViewItem item in listView3.Items)
                {
                    if (item.Index != e.Item.Index)
                        item.Checked = false;
                }
            }

            doValidation();
        }

        private void ListView4_ItemChecked(object sender, ItemCheckedEventArgs e)
        {
            if (e.Item.Checked == true)
            {
                foreach (ListViewItem item in listView4.Items)
                {
                    if (item.Index != e.Item.Index)
                        item.Checked = false;
                }
            }

            doValidation();
        }

        private void ListView2_ItemChecked(object sender, ItemCheckedEventArgs e)
        {
            if (listView2.CheckedItems.Count == 10)
                t2Hazir = true;
            else
                t2Hazir = false;

            doValidation();

            if (listView2.CheckedItems.Count == 10)
                label4.ForeColor = Color.Green;
            else
                label4.ForeColor = Color.DarkRed;

            label4.Text = listView2.CheckedItems.Count + " adet oyuncu seçtiniz.";
        }

        public Form5(object takim1, object takim2)
        {
            InitializeComponent();
            this.takim1 = (Takim)takim1;
            this.takim2 = (Takim)takim2;
        }
    }
}
