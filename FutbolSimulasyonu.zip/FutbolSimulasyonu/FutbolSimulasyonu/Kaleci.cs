﻿namespace FutbolSimulasyonu
{
    internal class Kaleci : Futbolcu
    {
        public byte SutKurtarma
        {
            get;
            set;
        }
        public byte PenaltiKurtarma
        {
            get;
            set;
        }
        public byte KafaKurtarma
        {
            get;
            set;
        }
        public byte FrikikKurtarma
        {
            get;
            set;
        }
        public byte TekeTekKurtarma
        {
            get;
            set;
        }
        public Kaleci(int ID, string Adi, string Soyadi, Takim Takim, Millet Millet, byte SutKurtarma, byte PenaltiKurtarma, byte KafaKurtarma, byte FrikikKurtarma, byte TekeTekKurtarma)
        {
            this.ID = ID;
            this.Adi = Adi;
            this.Soyadi = Soyadi;
            this.Takim = Takim;
            this.Millet = Millet;
            this.SutKurtarma = SutKurtarma;
            this.PenaltiKurtarma = PenaltiKurtarma;
            this.KafaKurtarma = KafaKurtarma;
            this.FrikikKurtarma = FrikikKurtarma;
            this.TekeTekKurtarma = TekeTekKurtarma;
        }
    }
}