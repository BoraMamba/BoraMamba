﻿namespace FutbolSimulasyonu
{
    internal class Oyuncu : Futbolcu
    {
        public string OyuncuMevki
        {
            get;
            set;
        }
        public byte PasVerme
        {
            get;
            set;
        }
        public byte PasKesme
        {
            get;
            set;
        }
        public byte SutAtma
        {
            get;
            set;
        }
        public byte SutEngelleme
        {
            get;
            set;
        }
        public byte PenaltiAtma
        {
            get;
            set;
        }
        public byte PenaltiyaSebebiyetVermeme
        {
            get;
            set;
        }
        public byte PenaltiYaptirma
        {
            get;
            set;
        }
        public byte FrikikKullanma
        {
            get;
            set;
        }
        public byte KornerKullanma
        {
            get;
            set;
        }
        public byte KafaHakimiyeti
        {
            get;
            set;
        }
        public byte Bitiricilik
        {
            get;
            set;
        }

        public Oyuncu(int ID, string Adi, string Soyadi, Takim Takim, Millet Millet, string OyuncuMevki, byte PasVerme, byte PasKesme, byte SutAtma, byte SutEngelleme, byte PenaltiAtma, byte PenaltiyaSebebiyetVermeme, byte PenaltiYaptirma, byte FrikikKullanma, byte KornerKullanma, byte KafaHakimiyeti, byte Bitiricilik)
        {
            this.ID = ID;
            this.Adi = Adi;
            this.Soyadi = Soyadi;
            this.Takim = Takim;
            this.Millet = Millet;
            this.OyuncuMevki = OyuncuMevki;
            this.PasVerme = PasVerme;
            this.PasKesme = PasKesme;
            this.SutAtma = SutAtma;
            this.SutEngelleme = SutEngelleme;
            this.PenaltiAtma = PenaltiAtma;
            this.PenaltiyaSebebiyetVermeme = PenaltiyaSebebiyetVermeme;
            this.PenaltiYaptirma = PenaltiYaptirma;
            this.FrikikKullanma = FrikikKullanma;
            this.KornerKullanma = KornerKullanma;
            this.KafaHakimiyeti = KafaHakimiyeti;
            this.Bitiricilik = Bitiricilik;
        }
    }
}