﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FutbolSimulasyonu
{
    class Takim
    {
        public int ID
        {
            get;
            set;
        }
        public string TakimAdi
        {
            get;
            set;
        }

        public long Seyirci
        {
            get;
            set;
        }

        public List<Oyuncu> Oyuncular
        {
            get;
            set;
        }

        public List<Kaleci> Kaleci
        {
            get;
            set;
        }

        public Takim(int ID, string TakimAdi, long Seyirci, List<Oyuncu> Oyuncular = null, List<Kaleci> Kaleci = null)
        {
            this.ID = ID;
            this.TakimAdi = TakimAdi;
            this.Seyirci = Seyirci;
            this.Oyuncular = Oyuncular;
            this.Kaleci = Kaleci;
        }
    }
}
