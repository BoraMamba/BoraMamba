﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Collections;
using System.Threading;
using System.Drawing.Text;
using System.Runtime.InteropServices;

/* 
   http://kodevreni.com
   Halit IZGIN(Ready)
   Bu uygulamanın geliştirilmesi tamamen serbesttir.
   Paylaşılması ise kaynak belirtmek şartıyla serbesttir.
   
*/

namespace FutbolSimulasyonu
{
    public partial class Form2 : Form
    {
        public Form2(object takim1, object takim2)
        {
            InitializeComponent();
            this.takim1 = (Takim)takim1;
            this.takim2 = (Takim)takim2;
        }

        Takim takim1, takim2;

        int macsuresi = 0;

        List<Gol> goller = new List<Gol>();

        private bool Penalti(Oyuncu atakOyuncu, Oyuncu savunanOyuncu, OyuncuFonksiyonlari fonk1, Skor skor, Anlatim anlatim, Takim pozisyon, Takim savunan)
        {
            Random rast = new Random();
            int atakPenalti = rast.Next(1, atakOyuncu.PenaltiYaptirma + 1);
            int savunmaPenalti = rast.Next(1, savunanOyuncu.PenaltiyaSebebiyetVermeme + 1);
            if (savunmaPenalti > atakPenalti)
            {
                Oyuncu penaltiAtan = fonk1.RastgeleOyuncu("Orta Saha");
                anlatim.Ekle(pozisyon, null, Anlatim.PozisyonTuru.PENALTI, macsuresi, penaltiAtan, null, savunanOyuncu);
                Application.DoEvents();
                Thread.Sleep(2500);
                int penaltiAtmaRast = rast.Next(1, penaltiAtan.PenaltiAtma + 1);
                int penaltiKurRast = rast.Next(1, savunan.Kaleci[0].PenaltiKurtarma + 1);
                if (penaltiAtmaRast > penaltiKurRast)
                {
                    Gol gol = skor.Gol(penaltiAtan.ID, macsuresi);
                    goller.Add(gol);
                    SkorEkle(pozisyon.ID);
                    anlatim.Ekle(pozisyon, null, Anlatim.PozisyonTuru.PENALTIGOL, macsuresi, penaltiAtan, null, savunanOyuncu);
                }
                else if (penaltiKurRast > penaltiAtmaRast)
                {
                    anlatim.Ekle(pozisyon, null, Anlatim.PozisyonTuru.PENALTIKACIRDI, macsuresi, penaltiAtan, null, savunanOyuncu);
                }
                else
                {
                    anlatim.Ekle(pozisyon, null, Anlatim.PozisyonTuru.DIREK, macsuresi, penaltiAtan, null, savunanOyuncu);
                }
                return true;
            }
            else
                return false;
        }

        PrivateFontCollection pfc = new PrivateFontCollection();

        private void Form2_Load(object sender, EventArgs e)
        {
            label1.Text = takim1.TakimAdi;
            label2.Text = takim2.TakimAdi;
            Champions.Font(pfc);
            sure.Font = new Font(pfc.Families[0], sure.Font.Size);
            label3.Font = new Font(pfc.Families[0], label3.Font.Size);
            skor1.Font = new Font(pfc.Families[0], skor1.Font.Size);
            skor2.Font = new Font(pfc.Families[0], skor2.Font.Size);
            label1.Font = new Font(pfc.Families[0], label1.Font.Size);
            label2.Font = new Font(pfc.Families[0], label2.Font.Size);
            label4.Font = new Font(pfc.Families[0], label4.Font.Size);
            label5.Font = new Font(pfc.Families[0], label5.Font.Size);
            label6.Font = new Font(pfc.Families[0], label6.Font.Size);
            label7.Font = new Font(pfc.Families[0], label7.Font.Size);
            label8.Font = new Font(pfc.Families[0], label8.Font.Size);

            label6.Left = (panel7.ClientSize.Width - label6.Width) / 2;
            label7.Left = (panel7.ClientSize.Width - label7.Width) / 2;

            panel3.Size = new Size(label1.Width + 20, panel3.Height);
            panel2.Size = new Size(panel3.Size.Width, panel2.Height);
            panel4.Size = new Size(label2.Width + 20, panel4.Height);
            panel6.Size = new Size(panel4.Width, panel6.Height);

            label4.Left = (panel2.ClientSize.Width - label4.Width) / 2;
            label5.Left = (panel6.ClientSize.Width - label5.Width) / 2;

            int tamUzunluk = panel1.Width + panel3.Width + panel4.Width + panel5.Width;
            int kalacak = (600 - tamUzunluk) / 2;

            panel1.Location = new Point(kalacak, panel1.Location.Y);
            panel3.Location = new Point(panel1.Location.X + panel1.Width, panel3.Location.Y);
            panel2.Location = new Point(panel3.Location.X, panel2.Location.Y);

            panel5.Location = new Point(panel1.Location.X + panel1.Width + panel3.Width, panel5.Location.Y);
            panel7.Location = new Point(panel5.Location.X, panel7.Location.Y);

            panel4.Location = new Point(panel1.Location.X + panel1.Width + panel3.Width + panel5.Width, panel4.Location.Y);
            panel6.Location = new Point(panel4.Location.X, panel6.Location.Y);

            label4.Location = new Point(50, label4.Location.Y);
            label5.Location = new Point(50, label5.Location.Y);
        }

        private void SkorEkle(int golAtanTakimId)
        {
            if (golAtanTakimId == takim1.ID)
            {
                skor1.Hide();
                skor1.Text = (Convert.ToInt32(skor1.Text) + 1).ToString();
                bunifuTransition1.ShowSync(skor1);
            }
            else
            {
                skor2.Hide();
                skor2.Text = (Convert.ToInt32(skor2.Text) + 1).ToString();
                bunifuTransition1.ShowSync(skor2);
            }
        }

        int takim1Oynama = 0, takim2Oynama = 0;

        private void ToplaOynama()
        {
            int tamSayi = 600;
            int tamOynama = takim1Oynama + takim2Oynama;
            double takim1Yuzde = Convert.ToDouble(takim1Oynama) / tamOynama * 100;
            double takim2Yuzde = Convert.ToDouble(takim2Oynama) / tamOynama * 100;
            double takim1Olcu = (tamSayi / 100) * takim1Yuzde;
            double takim2Olcu = (tamSayi / 100) * takim2Yuzde;

            evSahibiOynama.Size = new Size(Convert.ToInt32(takim1Olcu), evSahibiOynama.Height);
            deplasmanOynama.Size = new Size(Convert.ToInt32(takim2Olcu), deplasmanOynama.Height);

            deplasmanOynama.Location = new Point(evSahibiOynama.Size.Width, deplasmanOynama.Location.Y);

            label4.Text = "%" + Convert.ToInt32(takim1Yuzde);
            label5.Text = "%" + Convert.ToInt32(takim2Yuzde);
            label4.Left = (panel2.ClientSize.Width - label4.Width) / 2;
            label5.Left = (panel6.ClientSize.Width - label5.Width) / 2;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Random rast = new Random();
            int pozisyonolasiligi = rast.Next(0, 101);
            if (pozisyonolasiligi >= 0 && pozisyonolasiligi <= 30)
            {
                int takimIhtimal = rast.Next(0, 100);
                Takim pozisyon;
                Takim savunan;
                if (takimIhtimal % 2 == 0)
                {
                    pozisyon = takim1;
                    takim1Oynama++;
                    savunan = takim2;
                }
                else
                {
                    pozisyon = takim2;
                    takim2Oynama++;
                    savunan = takim1;
                }
                ToplaOynama();
                timer1.Stop();
                timer2.Stop();
                
                Anlatim anlatim = new Anlatim(richTextBox1);
                Skor skor = new Skor(takim1, takim2);
                switch (Pozisyon.RastgelePozisyonUret())
                {

                    case Pozisyon.PozisyonTuru.KORNER:
                        OyuncuFonksiyonlari fonk1 = new OyuncuFonksiyonlari(pozisyon.Oyuncular);
                        Oyuncu korneriKullanan = fonk1.RastgeleOyuncu("Orta Saha");
                        anlatim.Ekle(pozisyon, korneriKullanan, Anlatim.PozisyonTuru.KORNER, macsuresi);
                        Application.DoEvents();
                        Thread.Sleep(2500);
                        Oyuncu atakKafa = fonk1.RastgeleOyuncu("Defans");
                        if (rast.Next(1, korneriKullanan.KornerKullanma + 1) > 4)
                        {
                            OyuncuFonksiyonlari fonk2 = new OyuncuFonksiyonlari(savunan.Oyuncular);
                            Oyuncu savunanKafa = fonk2.RastgeleOyuncu("Defans");
                            int atakSayi = rast.Next(1, atakKafa.KafaHakimiyeti + 1);
                            int savunanSayi = rast.Next(1, savunanKafa.KafaHakimiyeti + 1);
                            if (atakSayi > savunanSayi)
                            {
                                int kaleciKafaKurtarma = rast.Next(1, savunan.Kaleci[0].KafaKurtarma + 1);
                                if (atakSayi > kaleciKafaKurtarma)
                                {
                                    bool penalti = Penalti(atakKafa, savunanKafa, fonk1, skor, anlatim, pozisyon, savunan);
                                    if (!penalti)
                                    {
                                        Gol gol = skor.Gol(atakKafa.ID, macsuresi);
                                        goller.Add(gol);

                                        SkorEkle(pozisyon.ID);

                                        anlatim.Ekle(null, korneriKullanan, Anlatim.PozisyonTuru.KORNERKAFAGOL, macsuresi, atakKafa);
                                    }
                                }
                                else if (kaleciKafaKurtarma > atakSayi)
                                {
                                    anlatim.Ekle(pozisyon, korneriKullanan, Anlatim.PozisyonTuru.KORNERKAFAKACIRDI, macsuresi, atakKafa);
                                }
                                else
                                {
                                    anlatim.Ekle(pozisyon, korneriKullanan, Anlatim.PozisyonTuru.DIREK, macsuresi, atakKafa);
                                }
                            }
                            else if (savunanSayi > atakSayi)
                            {
                                anlatim.Ekle(pozisyon, korneriKullanan, Anlatim.PozisyonTuru.KORNERKAFAKACIRDI, macsuresi, atakKafa);
                            }
                            else
                            {
                                anlatim.Ekle(pozisyon, korneriKullanan, Anlatim.PozisyonTuru.KORNERKIMSEDOKUNMADI, macsuresi, atakKafa);
                            }
                        }
                        else
                        {
                            anlatim.Ekle(pozisyon, korneriKullanan, Anlatim.PozisyonTuru.KORNERBASARISIZ, macsuresi, atakKafa);
                        }

                        macsuresi++;
                        sure.Text = macsuresi.ToString();
                        break;
                    case Pozisyon.PozisyonTuru.SERBESTVURUS:
                        OyuncuFonksiyonlari ser1 = new OyuncuFonksiyonlari(pozisyon.Oyuncular);
                        Oyuncu kullanan = ser1.RastgeleOyuncu("Orta Saha");
                        anlatim.Ekle(pozisyon, kullanan, Anlatim.PozisyonTuru.SERBESTVURUS, macsuresi);
                        Application.DoEvents();
                        Thread.Sleep(2500);
                        int islem = rast.Next(0, 100);
                        if (islem % 2 == 0)
                        {
                            int kullananFrikik = kullanan.FrikikKullanma;
                            int kaleciFrikik = savunan.Kaleci[0].FrikikKurtarma;
                            int kullananRast = rast.Next(1, kullananFrikik + 1);
                            int kaleciRast = rast.Next(1, kaleciFrikik + 1);
                            if (kullananRast > kaleciRast)
                            {
                                Gol gol = skor.Gol(kullanan.ID, macsuresi);
                                goller.Add(gol);
                                SkorEkle(pozisyon.ID);
                                anlatim.Ekle(pozisyon, null, Anlatim.PozisyonTuru.SERBESTVURUSGOL, macsuresi, kullanan);
                            }
                            else if (kaleciRast > kullananRast)
                            {
                                anlatim.Ekle(pozisyon, null, Anlatim.PozisyonTuru.SERBESTVURUSKACIRDI, macsuresi, kullanan);
                            }
                            else
                            {
                                anlatim.Ekle(pozisyon, null, Anlatim.PozisyonTuru.DIREK, macsuresi, kullanan);
                            }
                        }
                        else
                        {
                            Oyuncu kafaVuran = ser1.RastgeleOyuncu("Forvet");
                            OyuncuFonksiyonlari ser2 = new OyuncuFonksiyonlari(savunan.Oyuncular);
                            Oyuncu kafaSavunma = ser2.RastgeleOyuncu("Defans");
                            int frikikRast = rast.Next(1, kullanan.FrikikKullanma + 1);
                            if (frikikRast > 3)
                            {
                                int atakRast = rast.Next(1, kafaVuran.KafaHakimiyeti + 1);
                                int savunRast = rast.Next(1, kafaSavunma.KafaHakimiyeti + 1);
                                if (atakRast > savunRast)
                                {
                                    bool penalti = Penalti(kafaVuran, kafaSavunma, ser1, skor, anlatim, pozisyon, savunan);
                                    if (!penalti)
                                    {
                                        Gol gol = skor.Gol(kafaVuran.ID, macsuresi);
                                        goller.Add(gol);
                                        SkorEkle(pozisyon.ID);
                                        anlatim.Ekle(pozisyon, kullanan, Anlatim.PozisyonTuru.SERBESTVURUSKAFAGOL, macsuresi, kafaVuran);
                                    }
                                }
                                else if (savunRast > atakRast)
                                {
                                    anlatim.Ekle(pozisyon, kullanan, Anlatim.PozisyonTuru.SERBESTVURUSKAFAKACIRDI, macsuresi, kafaVuran);
                                }
                                else
                                {
                                    anlatim.Ekle(pozisyon, kullanan, Anlatim.PozisyonTuru.DIREK, macsuresi, kafaVuran);
                                }
                            }
                            else
                            {
                                anlatim.Ekle(pozisyon, kullanan, Anlatim.PozisyonTuru.SERBESTVURUSHATA, macsuresi);
                            }
                        }

                        macsuresi++;
                        sure.Text = macsuresi.ToString();
                        break;
                    case Pozisyon.PozisyonTuru.ORGANIZEATAK:
                        OyuncuFonksiyonlari org1 = new OyuncuFonksiyonlari(pozisyon.Oyuncular);
                        Oyuncu baslatan = org1.RastgeleOyuncu("Orta Saha");
                        OyuncuFonksiyonlari org2 = new OyuncuFonksiyonlari(savunan.Oyuncular);
                        Oyuncu savunanDef = org2.RastgeleOyuncu("Defans");
                        anlatim.Ekle(pozisyon, baslatan, Anlatim.PozisyonTuru.ATAKBASLANGIC, macsuresi, null, savunan, savunanDef);
                        Application.DoEvents();
                        Thread.Sleep(2500);
                        int baslatanRast = rast.Next(1, baslatan.PasVerme + 1);
                        int savunanRast = rast.Next(1, savunanDef.PasKesme + 1);
                        if (baslatanRast > savunanRast)
                        {
                            int rastFark = baslatanRast - savunanRast;
                            Oyuncu pasiAlan = org1.RastgeleOyuncu("Forvet");
                            anlatim.Ekle(pozisyon, baslatan, Anlatim.PozisyonTuru.ATAKPASIVERDI, macsuresi, pasiAlan);
                            Application.DoEvents();
                            Thread.Sleep(2500);
                            if (rastFark > 2)
                            {
                                anlatim.Ekle(pozisyon, baslatan, Anlatim.PozisyonTuru.ATAKKARSIKARSIYA, macsuresi, pasiAlan);
                                Application.DoEvents();
                                Thread.Sleep(2500);
                                int pasiAlanRast = rast.Next(1, pasiAlan.SutAtma + 1);
                                int kaleciRast = rast.Next(1, savunan.Kaleci[0].SutKurtarma + 1);
                                if (pasiAlanRast > kaleciRast)
                                {
                                    bool penalti = Penalti(pasiAlan, savunanDef, org1, skor, anlatim, pozisyon, savunan);
                                    if (!penalti)
                                    {
                                        Gol gol = skor.Gol(pasiAlan.ID, macsuresi);
                                        goller.Add(gol);
                                        SkorEkle(gol.GolAtanTakim.ID);
                                        anlatim.Ekle(pozisyon, baslatan, Anlatim.PozisyonTuru.KARSIKARSIYAGOL, macsuresi, pasiAlan);
                                    }
                                }
                                else if (kaleciRast > pasiAlanRast)
                                {
                                    anlatim.Ekle(pozisyon, baslatan, Anlatim.PozisyonTuru.KARSIKARSIYAKACIRDI, macsuresi, pasiAlan);
                                }
                                else
                                {
                                    anlatim.Ekle(pozisyon, baslatan, Anlatim.PozisyonTuru.DIREK, macsuresi, pasiAlan);
                                }
                            }
                            else
                            {
                                savunanRast = rast.Next(1, savunanDef.SutEngelleme + 1);
                                int atakRast = rast.Next(1, pasiAlan.SutAtma + 1);
                                if (atakRast > savunanRast)
                                {
                                    int kaleciRast = rast.Next(1, savunan.Kaleci[0].SutKurtarma + 1);
                                    if (atakRast > kaleciRast)
                                    {
                                        Gol gol = skor.Gol(pasiAlan.ID, macsuresi);
                                        goller.Add(gol);
                                        SkorEkle(pozisyon.ID);
                                        anlatim.Ekle(pozisyon, baslatan, Anlatim.PozisyonTuru.SUTGOL, macsuresi, pasiAlan, null, savunanDef);
                                    }
                                    else if (kaleciRast > atakRast)
                                    {
                                        anlatim.Ekle(pozisyon, baslatan, Anlatim.PozisyonTuru.SUTKACIRDI, macsuresi, pasiAlan, null, savunanDef);
                                    }
                                    else
                                    {
                                        anlatim.Ekle(pozisyon, baslatan, Anlatim.PozisyonTuru.DIREK, macsuresi, pasiAlan);
                                    }
                                }
                                else
                                {
                                    anlatim.Ekle(pozisyon, baslatan, Anlatim.PozisyonTuru.SAVUNMAMUDAHALE, macsuresi, pasiAlan, null, savunanDef);
                                }
                            }
                        }
                        
                        macsuresi++;
                        sure.Text = macsuresi.ToString();
                        break;
                }
                timer1.Start();
                timer2.Start();
            }
            else
            {
                macsuresi++;
                sure.Text = macsuresi.ToString();
            }

            if (macsuresi == 45)
            {
                bunifuFlatButton1.Enabled = true;
                kusurat = 0;
                sure.Text = macsuresi.ToString();
                timer1.Stop();
                timer2.Stop();
            }
            else if (macsuresi == 90)
            {
                timer1.Stop();
                timer2.Stop();
                kusurat = 0;
                sure.Text = macsuresi.ToString();
            }
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            Form1 form1 = (Form1)Application.OpenForms["Form1"];
            form1.Show();
        }

        int kusurat = 0;

        private void Timer2_Tick(object sender, EventArgs e)
        {
            if (kusurat < 53)
                kusurat += 7;
            else
                kusurat = (kusurat + 7) % 60;

            string eklenecek;
            if (kusurat < 10)
                eklenecek = "0" + kusurat;
            else
                eklenecek = kusurat.ToString();

            string ilk = sure.Text.Substring(0, 3);
            sure.Text = ilk + eklenecek;
        }

        private void Timer3_Tick(object sender, EventArgs e)
        {
            Console.WriteLine("Başlangıç");
            if (kusurat == 59)
            {
                kusurat = 0;
                macsuresi++;
            }
            else
                kusurat++;

            Console.WriteLine("Orta");

            sure.Text = macsuresi.ToString();

            Console.WriteLine(macsuresi + ":" + kusurat);
        }

        private void BunifuFlatButton1_Click(object sender, EventArgs e)
        {
            timer1.Start();
            bunifuFlatButton1.Enabled = false;
            timer2.Start();
        }

        private void RichTextBox1_TextChanged(object sender, EventArgs e)
        {
            richTextBox1.SelectionStart = richTextBox1.Text.Length;
            richTextBox1.ScrollToCaret();
        }

        private void BunifuImageButton1_Click(object sender, EventArgs e)
        {
            Form1 form1 = (Form1)Application.OpenForms["Form1"];
            form1.Show();
            this.Hide();
        }

        private void BunifuImageButton2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Sure_TextChanged(object sender, EventArgs e)
        {
            int l = sure.Text.Length;
            string eklenecek;
            if (kusurat < 10)
                eklenecek = "0" + kusurat;
            else
                eklenecek = kusurat.ToString();

            if (l == 1)
                sure.Text = "0" + sure.Text + ":" + eklenecek;
            else if (l == 2)
                sure.Text = sure.Text + ":" + eklenecek;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
            bunifuFlatButton1.Enabled = false;
            timer2.Start();
        }
    }
}
