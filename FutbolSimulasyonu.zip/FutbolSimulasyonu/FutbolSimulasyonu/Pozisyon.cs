﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FutbolSimulasyonu
{
    class Pozisyon
    {
        public enum PozisyonTuru
        {
            KORNER,
            SERBESTVURUS,
            ORGANIZEATAK,

        }

        public static PozisyonTuru RastgelePozisyonUret()
        {
            Random random = new Random();
            int rast = random.Next(1, 101);
            if (rast >= 1 && rast <= 5)
                return PozisyonTuru.KORNER;
            else if (rast >= 6 && rast <= 10)
                return PozisyonTuru.SERBESTVURUS;
            else
                return PozisyonTuru.ORGANIZEATAK;
        }
    }
}
