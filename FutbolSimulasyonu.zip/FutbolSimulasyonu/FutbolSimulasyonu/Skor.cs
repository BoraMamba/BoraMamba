﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FutbolSimulasyonu
{
    class Skor
    {
        public Takim takim1
        {
            get;
            set;
        }
        public Takim takim2
        {
            get;
            set;
        }
        public Gol Gol(int golAtanID, int golDakika)
        {
            Oyuncu atan = takim1.Oyuncular.Find(i => i.ID == golAtanID);
            if (atan == null)
            {
                atan = takim2.Oyuncular.Find(i => i.ID == golAtanID);
                return new Gol(atan, takim2, golDakika);
            }
            else
                return new Gol(atan, takim1, golDakika);
        }

        public Skor(Takim takim1, Takim takim2)
        {
            this.takim1 = takim1;
            this.takim2 = takim2;
        }
    }
}
