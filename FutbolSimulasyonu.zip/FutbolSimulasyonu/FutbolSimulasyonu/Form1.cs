﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Drawing.Text;
using Bunifu.Framework.UI;

/* 
   http://kodevreni.com
   Halit IZGIN(Ready)
   Bu uygulamanın geliştirilmesi tamamen serbesttir.
   Paylaşılması ise kaynak belirtmek şartıyla serbesttir.
   
*/

namespace FutbolSimulasyonu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void yenile()
        {
            comboBox1.Items.Clear();
            comboBox2.Items.Clear();
            List<Takim> takimlar = DB.TakimlariAl();
            comboBox1.DisplayMember = "TakimAdi";
            comboBox2.DisplayMember = "TakimAdi";
            comboBox1.ValueMember = "ID";
            comboBox2.ValueMember = "ID";
            foreach (Takim item in takimlar)
            {
                comboBox1.Items.Add(item);
                comboBox2.Items.Add(item);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            yenile();
            PrivateFontCollection pfc = new PrivateFontCollection();
            Champions.Font(pfc);
            foreach (Control item in this.Controls)
            {
                if (item is BunifuFlatButton)
                    ((BunifuFlatButton)item).TextFont = new Font(pfc.Families[0], ((BunifuFlatButton)item).TextFont.Size);
                else
                    item.Font = new Font(pfc.Families[0], item.Font.Size);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            yenile();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text != comboBox2.Text && comboBox1.Text != "" && comboBox2.Text != "")
            {
                Form5 form5 = new Form5((Takim)comboBox1.SelectedItem, (Takim)comboBox2.SelectedItem);
                form5.Show();
                this.Hide();
            }
        }

        private void OyuncuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            form4.ShowDialog();
        }

        private void TakımToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.ShowDialog();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.ExitThread();
        }

        private void BunifuFlatButton1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text != comboBox2.Text && comboBox1.Text != "" && comboBox2.Text != "")
            {
                Form5 form5 = new Form5((Takim)comboBox1.SelectedItem, (Takim)comboBox2.SelectedItem);
                form5.Show();
                this.Hide();
            }
        }

        private void BunifuFlatButton2_Click(object sender, EventArgs e)
        {
            yenile();
        }

        private void BunifuFlatButton3_Click(object sender, EventArgs e)
        {
            contextMenuStrip1.Show(new Point(Cursor.Position.X, Cursor.Position.Y));
        }

        private void BunifuImageButton1_Click(object sender, EventArgs e)
        {
            Application.ExitThread();
        }

        private void BunifuImageButton2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
