﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FutbolSimulasyonu
{
    class Anlatim
    {
        public enum PozisyonTuru
        {
            KORNER,
            SERBESTVURUS,
            PENALTI,
            PENALTIGOL,
            PENALTIKACIRDI,
            KORNERKAFAGOL,
            KORNERKAFAKACIRDI,
            SERBESTVURUSGOL,
            SERBESTVURUSKACIRDI,
            SERBESTVURUSKAFAGOL,
            SERBESTVURUSKAFAKACIRDI,
            SERBESTVURUSHATA,
            PASKESTI,
            KARSIKARSIYAGOL,
            KARSIKARSIYAKACIRDI,
            DIREK,
            KORNERKIMSEDOKUNMADI,
            KORNERBASARISIZ,
            SUTGOL,
            SUTKACIRDI,
            ATAKBASLANGIC,
            ATAKPASIVERDI,
            ATAKKARSIKARSIYA,
            SAVUNMAMUDAHALE
        }

        public RichTextBox text
        {
            get;
            set;
        }

        public Anlatim(RichTextBox text)
        {
            this.text = text;
        }

        public void YaziEkle(PrivateFontCollection pfc, int dakika, string metin)
        {
            text.Text += String.Format("{0}' {1}\n", dakika, metin);
            text.Font = new Font(pfc.Families[0], 10);
        }

        public void Ekle(Takim atakTakim, Oyuncu pasiVeren, PozisyonTuru tur, int dakika, Oyuncu atakOyuncu = null, Takim savunnaTakim = null, Oyuncu savunmaOyuncu = null)
        {
            PrivateFontCollection pfc = new PrivateFontCollection();
            Champions.Font(pfc);
            switch (tur)
            {
                case PozisyonTuru.KORNER:
                    YaziEkle(pfc, dakika, String.Format("{0} korner kazandı. Korneri {1} kullanacak.", atakTakim.TakimAdi, pasiVeren.TamAd));
                    break;
                case PozisyonTuru.SERBESTVURUS:
                    YaziEkle(pfc, dakika, String.Format("{0} serbest vuruş kazandı. Serbest vuruşu {1} kullanacak.", atakTakim.TakimAdi, pasiVeren.TamAd));
                    break;
                case PozisyonTuru.PENALTI:
                    YaziEkle(pfc, dakika, String.Format("Penaltı! {0} penaltı kazandı. {1} tarafından yapılan müdahale penaltıya sebebiyet verdi. Penaltıyı {2} kullanacak.", atakTakim.TakimAdi, savunmaOyuncu.TamAd, atakOyuncu.TamAd));
                    break;
                case PozisyonTuru.PENALTIGOL:
                    YaziEkle(pfc, dakika, String.Format("Gol! Penaltı sonucunda topun başına geçen {0}, güzel bir vuruşla golü buluyor.", atakOyuncu.TamAd));
                    break;
                case PozisyonTuru.PENALTIKACIRDI:
                    YaziEkle(pfc, dakika, String.Format("Penaltı kaçtı! Penaltı sonucunda topun başına geçen {0}, penaltı atışını kaçırıyor.", atakOyuncu.TamAd));
                    break;
                case PozisyonTuru.KORNERKAFAGOL:
                    YaziEkle(pfc, dakika, String.Format("Gol! Kornerin kullanan {0}, adrese teslim bir orta açıyor. Kafa vuruşunu yapan {1}, topu ağlarla buluşturuyor.", pasiVeren.TamAd, atakOyuncu.TamAd));
                    break;
                case PozisyonTuru.KORNERKAFAKACIRDI:
                    YaziEkle(pfc, dakika, String.Format("Top dışarıda. Korneri kullanan {0} kavisli bir orta yapıyor. Ancak topa kafa vuran {1}, kaleyi bulamıyor.", pasiVeren.TamAd, atakOyuncu.TamAd));
                    break;
                case PozisyonTuru.SERBESTVURUSGOL:
                    YaziEkle(pfc, dakika, String.Format("Gol! Serbest vuruşta harika ve falsolu bir vuruş yapan {0}, topu ağlarla buluşturuyor.", atakOyuncu.TamAd));
                    break;
                case PozisyonTuru.SERBESTVURUSKACIRDI:
                    YaziEkle(pfc, dakika, String.Format("Top kalecide. Serbest vuruşu kullanan {0}, yaptığı vuruş kalecide kalıyor.", atakOyuncu.TamAd));
                    break;
                case PozisyonTuru.DIREK:
                    YaziEkle(pfc, dakika, String.Format("Top direkten döndü. {0} vuruşunu yaptı ancak top direkten geri geldi.", atakOyuncu.TamAd));
                    break;
                case PozisyonTuru.KORNERKIMSEDOKUNMADI:
                    YaziEkle(pfc, dakika, String.Format("Topa kimse dokunamadı. Top yandan dışarıya çıktı."));
                    break;
                case PozisyonTuru.KORNERBASARISIZ:
                    YaziEkle(pfc, dakika, String.Format("Orta direk olarak dışarı çıkıyor."));
                    break;
                case PozisyonTuru.SERBESTVURUSKAFAGOL:
                    YaziEkle(pfc, dakika, String.Format("Gol! Serbest vuruşta {0} adrese teslim orta yaptı. Kafa vuruşunu düzgün yapan {1}, topu ağlarla buluşturdu.", pasiVeren.TamAd, atakOyuncu.TamAd));
                    break;
                case PozisyonTuru.SERBESTVURUSKAFAKACIRDI:
                    YaziEkle(pfc, dakika, String.Format("Gol! Serbest vuruşta {0} ortayı yaptı. Kafa vuruşunu yapan {1}, çerçeveyi bulamadı.", pasiVeren.TamAd, atakOyuncu.TamAd));
                    break;
                case PozisyonTuru.SERBESTVURUSHATA:
                    YaziEkle(pfc, dakika, String.Format("Serbest vuruşu kötü kullanan {0}, vuruşu direk olarak dışarıya gidiyor.", pasiVeren.TamAd));
                    break;
                case PozisyonTuru.SUTGOL:
                    YaziEkle(pfc, dakika, String.Format("{0} tarafından verilen pasla {1} dan kurtulup kaleciyle karşı karşıya kalan {2}, topu ağlarla buluşturdu.", pasiVeren.TamAd, savunmaOyuncu.TamAd,atakOyuncu.TamAd));
                    break;
                case PozisyonTuru.SUTKACIRDI:
                    YaziEkle(pfc, dakika, String.Format("{0} tarafından verilen pasla {1} dan kurtulup karşı karşıya kalan {2}, topu dışarı gönderdi.", pasiVeren.TamAd, pasiVeren.TamAd, atakOyuncu.TamAd));
                    break;
                case PozisyonTuru.ATAKBASLANGIC:
                    YaziEkle(pfc, dakika, String.Format("{0} pası aldı. Pas verecek arkadaşlarını arıyor. Önünde olan {1} ona engel olmaya çalışıyor.", pasiVeren.TamAd, savunmaOyuncu.TamAd));
                    break;
                case PozisyonTuru.ATAKPASIVERDI:
                    YaziEkle(pfc, dakika, String.Format("{0} tarafından atılan pasla {1} topla buluştu.", pasiVeren.TamAd, atakOyuncu.TamAd));
                    break;
                case PozisyonTuru.ATAKKARSIKARSIYA:
                    YaziEkle(pfc, dakika, String.Format("{0} bir anda kaleciyle karşı karşıya kaldı.", atakOyuncu.TamAd));
                    break;
                case PozisyonTuru.KARSIKARSIYAGOL:
                    YaziEkle(pfc, dakika, String.Format("Gol! {0} tarafından atılan pasla karşı karşıya kalan {1}, düzgün bir vuruşla topu ağlara gönderiyor.", pasiVeren.TamAd, atakOyuncu.TamAd));
                    break;
                case PozisyonTuru.KARSIKARSIYAKACIRDI:
                    YaziEkle(pfc, dakika, String.Format("Karşı karşıya net pozisyon kaçtı! {0} tarafından atılan pasla karşı karşıya kalan {1}, vuruşunu yapıyor ancak kaleci son anda kurtarıyor.", pasiVeren.TamAd, atakOyuncu.TamAd));
                    break;
                case PozisyonTuru.SAVUNMAMUDAHALE:
                    YaziEkle(pfc, dakika, String.Format("{0} tarafından atılan pası alan {1}, {2} tarafından harika bir müdahale ile durduruluyor.", pasiVeren.TamAd, atakOyuncu.TamAd, savunmaOyuncu.TamAd));
                    break;
            }
        }
    }
}
