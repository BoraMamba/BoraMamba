﻿using System;
using System.Collections.Generic;
using System.Drawing.Text;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace FutbolSimulasyonu
{
    class Champions
    {
        public static void Font(PrivateFontCollection pfc)
        {
            int fontLength = Properties.Resources.Champions_Bold.Length;

            byte[] fontData = Properties.Resources.Champions_Bold;

            System.IntPtr data = Marshal.AllocCoTaskMem(fontLength);

            Marshal.Copy(fontData, 0, data, fontLength);

            pfc.AddMemoryFont(data, fontLength);
        }
    }
}
